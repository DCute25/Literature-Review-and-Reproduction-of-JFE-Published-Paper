import pandas as pd
import numpy as np

### Dow Jones Industrial index
df = pd.read_excel(r"C:\Users\Thu\Downloads\Dowjones.xlsx")
df['Date'] = pd.to_datetime(df['Date'])
# Sort the DataFrame by date in ascending order
df = df.sort_values(by='Date').reset_index(drop=True)
# Calculate 52-week high (assuming 252 trading days in a year)
df['52_Week_High'] = df['Close'].rolling(window=252, min_periods=1).max()
df['Historical_High'] = df['Close'].cummax()
df = df.dropna()
# Calculate nearness to 52-week high & nearness to historical high
df['Nearness_to_52_Week_High'] = df['Close'] / df['52_Week_High']
df['Nearness_to_Historical_High'] = df['Close'] / df['Historical_High']
# Dow historical high indicator (Dt)
df['Dt'] = (df['Close'] == df['Historical_High']).astype(int)
# 52-week high indicator (It)
df['It'] = (df['Historical_High'] == df['52_Week_High']).astype(int)
df.to_csv("dow_jones.csv")

### Load and transform main variables
## Load data
baa = pd.read_excel(r"C:\Users\Thu\Downloads\BAA.xlsx", parse_dates=["observation_date"], index_col="observation_date")
aaa = pd.read_excel(r"C:\Users\Thu\Downloads\AAA.xlsx", parse_dates=["observation_date"], index_col="observation_date")
gs20 = pd.read_csv(r"C:\Users\Thu\Downloads\GS20.csv", parse_dates=["observation_date"], index_col="observation_date")
gs1 = pd.read_csv(r"C:\Users\Thu\Downloads\GS1.csv", parse_dates=["observation_date"], index_col="observation_date")
crsp = pd.read_csv(r"C:\Users\Thu\Downloads\us_equity.csv")
cpi = pd.read_excel(r"C:\Users\Thu\Downloads\cpi.xlsx")
cay = pd.read_csv(r"C:\Users\Thu\Downloads\cay.csv", parse_dates=["time"], index_col="time")
consumption = pd.read_csv(r"C:\Users\Thu\Downloads\consumption.csv", parse_dates=["observation_date"], index_col="observation_date")
div = pd.read_csv(r"C:\Users\Thu\Downloads\dividend.csv", parse_dates=["date"])
totval = pd.read_csv(r"C:\Users\Thu\Downloads\marketvalue.csv",parse_dates=["DATE"])


## Transform data and set date
div['date'] = div['date'].dt.to_period('M').astype(str)
div = div.groupby("date")["DIVAMT"].sum().reset_index()
div.rename(columns={"DIVAMT": "total_market_dividends"}, inplace=True)
div["Rolling_12M_DIV"] = div["total_market_dividends"].rolling(window=12, min_periods=1).sum()

crsp['Year'] = crsp['Year'].astype(str)
crsp['Month'] = crsp['Year'].str[-2:]  
crsp['Year'] = crsp['Year'].str[:-2] 
crsp["date"] = crsp["Year"].astype(str) + "-" + crsp["Month"]
crsp = crsp.drop(['Month', 'Year'], axis=1)
crsp = crsp.set_index('date')

baa['date'] = baa.index.to_period('M').astype(str)
aaa['date'] = aaa.index.to_period('M').astype(str)
gs20['date'] = gs20.index.to_period('M').astype(str)
gs1['date'] = gs1.index.to_period('M').astype(str)
totval['date'] = totval['DATE'].dt.to_period('M').astype(str)

cpi = pd.DataFrame(cpi)
cpi = cpi.melt(id_vars=["Year"], var_name="Month", value_name="CPI")
month_map = {
    "Jan": "01", "Feb": "02", "Mar": "03", "Apr": "04",
    "May": "05", "Jun": "06", "Jul": "07", "Aug": "08",
    "Sep": "09", "Oct": "10", "Nov": "11", "Dec": "12"
}
cpi["Month"] = cpi["Month"].map(month_map)
cpi["date"] = cpi["Year"].astype(str) + "-" + cpi["Month"]

# Resample to monthly frequency by forward filling the last quarterly value
cay = cay.resample('ME').ffill()  
cay['date'] = cay.index.to_period('M').astype(str)

# Compute quarterly consumption growth (log difference)
consumption = consumption.sort_index()
consumption = consumption.resample('ME').ffill()
consumption['log_PCEC'] = np.log(consumption['PCEC'])
consumption['Growth'] = consumption['log_PCEC'].diff().fillna(0)
consumption['Growth'] = consumption['Growth'] * 100
consumption['St'] = consumption['Growth'].rolling(window=40, min_periods=1).mean()
consumption['date'] = consumption.index.to_period('M').astype(str)

# Merge data
data = baa.merge(aaa, on="date", suffixes=("_BAA", "_AAA"))
gs_data = gs20.merge(gs1, on="date", suffixes=("_20Y", "_1Y"))
data = data.merge(gs_data, on="date")
data = data.merge(cpi, on= "date")
data = data.merge(crsp, on= "date")
data = data.merge(cay, on= "date")
data = data.merge(consumption, on= "date")
data = data.merge(div, on= "date")
data = data.merge(totval, on= "date")

# Calculate
data["DEFt"] = data["BAA"] - data["AAA"]
data["TERMt"] = data["GS20"] - data["GS1"]
data["Inflation"] = data["CPI"].pct_change() * 1
data["Inflation"] = data["Inflation"] * 100
data["Real_interest"] = data["RF"] - data["Inflation"]
data["Value_weighted"] = data["RF"] + data["Mkt-RF"]
data["cay"] = data["cay"] * 100

data = data.sort_values(by='date')

# Calculate the log of the 12-month dividend (Rolling_12M_DIV) and the current CRSP index level
data['log_rolling_12M_div'] = np.log(data['Rolling_12M_DIV'])
data['VW_index'] = 100 * (1 + data['Value_weighted'] / 100).cumprod()
data['log_crsp_index'] = np.log(data['VW_index'])
data['dividend_yield'] = data['log_rolling_12M_div'] - data['log_crsp_index']
data['dividend_yield_1'] = data['Rolling_12M_DIV'] / data['VW_index']

# Calculate 52-week high
data['52_NY'] = data['totval'].rolling(window=12, min_periods=1).max()
data['max_NY'] = data['totval'].cummax()
data = data.dropna()

# Calculate nearness to 52-week high & nearness to historical high
data['Near_52_NY'] = data['totval'] / data['52_NY']
data['Near_max_NY'] = data['totval'] / data['max_NY']

# Dow historical high indicator (Dt)
data['D_NY'] = (data['totval'] == data['max_NY']).astype(int)

# 52-week high indicator (It) - equals 1 when historical high equals 52-week high
data['I_NY'] = (data['max_NY'] == data['52_NY']).astype(int)
data = data[['date', 'Mkt-RF','RF','cay','St','DEFt','TERMt','Inflation','Real_interest', 'Value_weighted','dividend_yield','Near_52_NY','Near_max_NY','D_NY','I_NY']]

# Save to CSV
data.to_csv("def_term_inf.csv")

print(data)

